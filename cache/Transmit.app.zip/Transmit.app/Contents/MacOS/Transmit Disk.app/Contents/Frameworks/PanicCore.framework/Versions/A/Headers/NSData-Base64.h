//
//  NSData-Base64.h
//  PanicCore
//
//  Created by Ian Cely on 12/16/09.
//  Copyright 2009 Panic Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSData (PCBase64)

+ (NSData*)pc_dataWithBase64String:(NSString*)string;
- (NSString*)pc_base64String;

//32
+ (NSData*)pc_dataWithBase32String:(NSString*)string;
- (NSString*)pc_base32String;

//16
- (NSString*)pc_base16String;


@end