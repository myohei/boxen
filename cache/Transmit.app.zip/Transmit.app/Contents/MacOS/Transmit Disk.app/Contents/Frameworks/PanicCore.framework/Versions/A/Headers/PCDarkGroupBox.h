#import <Cocoa/Cocoa.h>


@interface PCDarkGroupBox : NSView
{
	NSImage *iBackgroundImage;
	NSBoxType	iBoxType; // only supports NSBoxSeparator & NSBoxPrimary
}

+ (PCDarkGroupBox*)separatorWithWidth:(float)width;

@property (nonatomic, assign) NSBoxType boxType;

@end
