#import <Cocoa/Cocoa.h>


@interface PCLoginItem : NSObject
{
	NSString *iPath;
	NSString *iDisplayName;
	LSSharedFileListRef iLoginFileList;
}

@property (nonatomic, readonly, retain) NSString *path;
@property (nonatomic, readonly, retain) NSString *displayName;

- (id)initWithDisplayName:(NSString*)name path:(NSString*)path;

- (BOOL)installLoginItem;
- (BOOL)removeLoginItem;

- (BOOL)isLoginItem;
- (BOOL)updateLoginItemPathIfNeeded;

@end
