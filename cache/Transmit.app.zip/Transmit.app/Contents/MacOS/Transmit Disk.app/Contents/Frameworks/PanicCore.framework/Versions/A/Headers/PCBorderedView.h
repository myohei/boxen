#import "PCAppearanceView.h"
#import "PCControlsConfiguration.h"

@interface PCBorderedView : PCAppearanceView 
{
	PCControlBezelStyle	iBezel;
	NSColor				*iBorderColor;
	NSColor				*iSecondaryBorderColor; // inset 2 pts from edge
	NSColor				*iFillColor;
}

@property (nonatomic, retain) NSColor *borderColor;
@property (nonatomic, retain) NSColor *secondaryBorderColor;
@property (nonatomic, retain) NSColor *fillColor;
@property PCControlBezelStyle bezel;

- (void)configure;

@end
