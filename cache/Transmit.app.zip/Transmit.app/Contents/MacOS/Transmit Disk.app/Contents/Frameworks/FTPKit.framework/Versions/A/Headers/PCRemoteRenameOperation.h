#import <Cocoa/Cocoa.h>
#import "PCRemoteMoveOperation.h"

@class AbstractConnection;
@class PCRemoteFileNode;

@interface PCRemoteRenameOperation : PCRemoteMoveOperation
{
@private
	NSString* iPath;
	NSString* iOriginalFilename;
}

- (id)initWithNode:(PCRemoteFileNode*)node name:(NSString*)name;
- (id)initWithPath:(NSString*)path name:(NSString*)name;

@property (readonly) NSString* originalFilename;

@end
