//
//  NSProcessInfo-Additions.h
//  PanicCore
//
//  Created by Ned Holbrook on 2/5/10.
//  Copyright 2010 Panic Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSProcessInfo (PCAdditions)

- (void)pc_enableSuddenTermination;
- (void)pc_disableSuddenTermination;

- (NSString*)pc_architectureString; // eg: "x86_64"

@end
