#import "PCRemoteNewFileOperation.h"

@interface PCRemoteNewFolderOperation : PCRemoteNewFileOperation
{
	NSDictionary *iCustomAttributes;
}

@property (copy) NSDictionary *customAttributes; // allows the caller to provide custom new folder attributes

@end
