#import "PCFolderNode.h"


@interface PCVolumeNode : PCFolderNode
{
	BOOL	iRemovable;
	FSRef	iLocalRef;
	NSString *iLocalDisplayName;
	BOOL	iIsSymlink;
	BOOL	iIsBootDisk;
}

@property(nonatomic, getter=isRemovable) BOOL removable;

@end
