#import <Cocoa/Cocoa.h>

@interface PCChevronPopUpButton : NSPopUpButton
{
}

@end


@interface PCChevronPopUpButtonCell : NSPopUpButtonCell
{
}

@end
