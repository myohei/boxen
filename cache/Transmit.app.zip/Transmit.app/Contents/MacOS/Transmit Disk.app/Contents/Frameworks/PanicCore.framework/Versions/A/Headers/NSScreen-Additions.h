#import <Cocoa/Cocoa.h>


@interface NSScreen (Additions)

+ (NSRect)menuBarFrame;
+ (CGFloat)pc_highestBackingScaleFactor;

@end
