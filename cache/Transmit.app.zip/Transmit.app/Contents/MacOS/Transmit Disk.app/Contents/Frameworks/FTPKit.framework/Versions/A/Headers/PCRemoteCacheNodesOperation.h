#import "PCRemoteTransferOperation.h"

@class AbstractConnection;
@class PCNode;

@interface PCRemoteCacheNodesOperation : PCRemoteTransferOperation 
{
	BOOL iReplaceExistingFiles;
	BOOL iAllowRecache;
}

- (id)initWithNodes:(NSArray*)inNodes replaceExistingFiles:(BOOL)replace;
- (id)initWithNodes:(NSArray*)inNodes allowRecache:(BOOL)recache;

@end
