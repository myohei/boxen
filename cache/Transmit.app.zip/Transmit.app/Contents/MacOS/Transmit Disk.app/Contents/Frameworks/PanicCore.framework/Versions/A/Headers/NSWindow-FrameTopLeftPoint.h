#import <AppKit/AppKit.h>


@interface NSWindow (PCFrameTopLeftPoint)

- (NSPoint)pc_frameTopLeftPoint;
- (void)pc_centerOnScreen;

@end
