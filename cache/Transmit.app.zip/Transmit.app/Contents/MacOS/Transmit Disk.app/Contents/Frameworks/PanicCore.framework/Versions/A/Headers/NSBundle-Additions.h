#import <Foundation/Foundation.h>


@interface NSBundle (Additions)

- (NSBundle*)pc_outermostContainingBundle; // can return self

- (BOOL)pc_getCreatorCode:(OSType*)outCode; // outCode is left untouched on failure

@end
