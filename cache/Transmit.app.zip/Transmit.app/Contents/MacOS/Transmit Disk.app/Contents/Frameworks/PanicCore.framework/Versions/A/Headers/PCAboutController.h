@class PCURLButton;

/*
 *  PCAboutController.h
 *
 *  Requires Mac OS X 10.0 or higher,
 *	PCURLButton, NSString-Hyperlink.h, LocaleMacros.h
 *
 *	info.plist and info.strings: CFBundleVersion, CFBundleName, NSHumanReadableCopyright 
 *	
 *	localized strings: HomepageURL
 *
 *
 *	Provides the standard panic about box.
 *
 *	-------------------------------------------------------------------
 *
 *
 */

@interface PCAboutController : NSWindowController 
{
	IBOutlet PCURLButton* homePageButton;
	IBOutlet NSTextField* versionTextField;
	IBOutlet NSTextField* appNameTextField;
	IBOutlet NSTextField* copyrightTextField;
}

@end
