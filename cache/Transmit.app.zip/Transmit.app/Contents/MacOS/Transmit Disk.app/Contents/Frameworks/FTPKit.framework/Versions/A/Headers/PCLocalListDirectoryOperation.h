#import "PCFSOperation.h"


@class PCFolderNode;

@interface PCLocalListDirectoryOperation : PCFSOperation
{
	PCFolderNode* iNode;
	BOOL iShouldListContents;
}

- (id)initWithFolderNode:(PCFolderNode*)node;

@end


@interface PCLocalListDirectoryOperation (PreventUnnecessaryCasting)

+ (PCLocalListDirectoryOperation*)alloc;

@end
