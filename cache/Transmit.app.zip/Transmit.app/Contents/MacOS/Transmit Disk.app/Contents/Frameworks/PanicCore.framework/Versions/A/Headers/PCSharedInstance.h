#import <Foundation/Foundation.h>


// inheriting from this class allows for the creation of a singleton accessible via either +sharedInstance or +alloc/-init
@interface PCSharedInstance : NSObject <NSCopying>
{
}

+ (id)sharedInstance;

// SUBCLASSES MUST IMPLEMENT THIS: this method should return a pointer to an id with static storage duration
+ (id*)sharedInstancePtr;

- (id)init;

@end
