#import <Foundation/Foundation.h>


@interface NSDictionary (PCAdditions)

- (NSDictionary*)pc_dictionaryByAddingEntriesFromDictionary:(NSDictionary*)other;

@end


@interface NSMutableDictionary (PCAdditions)

// does nothing if object is nil
- (void)pc_setObject:(id)object forKey:(id)key;

@end
