#import <PanicCore/PanicCore.h>

@class PCCredentials;

@interface PCCredentialsSettingsProvider : PCSharedInstance
{
	id userlandProvider;
}

- (void)loadAdvancedSettingsForCredentials:(PCCredentials*)credential;
- (void)setUserlandProvider:(id)anObject;

@end

@interface PCCredentialsSettingsProvider (Redeclarations)

+ (PCCredentialsSettingsProvider*)sharedInstance;

@end

@interface NSObject (UserlandProviderMethod)
- (void)loadAdvancedSettingsForCredentials:(PCCredentials*)credential;
@end
