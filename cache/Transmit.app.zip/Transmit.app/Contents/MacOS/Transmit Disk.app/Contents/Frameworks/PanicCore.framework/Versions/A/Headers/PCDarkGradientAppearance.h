//
//  PCDarkGradientAppearance.h
//  PanicCore
//
//  Created by Logan Collins on 3/26/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PanicCore/PCAppearance.h>


/*!
 * @class PCDarkGradientAppearanceFactory
 * @abstract Factory for the Panic dark gradient UI element appearance
 */
@interface PCDarkGradientAppearanceFactory : NSObject <PCAppearanceFactory>

@end
