#import <Cocoa/Cocoa.h>
#import "PCRemoteOperation.h"

@class PCRemoteAliasNode;

@interface PCRemoteResolveSymlinkOperation : PCRemoteOperation
{
	PCRemoteAliasNode* iNode;
}

- (id)initWithAliasNode:(PCRemoteAliasNode*)inNode;

@end
