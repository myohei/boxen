//
//  PanicCoreDefines.h
//  PanicCore
//
//  Created by Logan Collins on 3/22/13.
//  Copyright (c) 2013 Panic Inc. All rights reserved.
//


#define PANICCORE_EXTERN extern __attribute__((visibility("default")))
#define PANICCORE_INLINE static inline __attribute__((visibility("default")))

#if (__has_feature(objc_fixed_enum))
#define PANICCORE_ENUM(_type, _name) enum _name : _type _name; enum _name : _type
#define PANICCORE_OPTIONS(_type, _name) enum _name : _type _name; enum _name : _type
#else
#define PANICCORE_ENUM(_type, _name) _type _name; enum
#define PANICCORE_OPTIONS(_type, _name) _type _name; enum
#endif
