//
//  RelativeDatesTemplate.h
//  RelativeDatesPredicateEditor
//
//  Created by Peter Ammon on 1/19/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface RelativeDatesTemplate : NSPredicateEditorRowTemplate {
    NSPopUpButton *unitsPopup;
}

@end
