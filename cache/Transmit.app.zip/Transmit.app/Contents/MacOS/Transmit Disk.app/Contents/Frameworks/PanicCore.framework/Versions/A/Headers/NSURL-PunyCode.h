#import <Foundation/Foundation.h>


@interface NSURL (PCPunyCode)

// returns self if conversion fails or no encoding is needed
- (NSURL*)pc_punyCode;

@end
