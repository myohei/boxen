#import <Cocoa/Cocoa.h>


@interface PCControllerView : NSView 
{
	NSViewController *iViewController;
}

@property (assign, readwrite) NSViewController *viewController;

@end


@interface NSViewController (PCControllerViewCallbacks)

- (void)view:(NSView*)view didMoveToWindow:(NSWindow*)window;
- (void)view:(NSView*)view willMoveToWindow:(NSWindow*)window;

- (void)view:(NSView*)view didMoveToSuperview:(NSView*)superview;
- (void)view:(NSView*)view willMoveToSuperview:(NSView*)superview;

@end