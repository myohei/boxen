//
//  CALayer-Additions.h
//  PanicCore
//
//  Created by Wade Cosgrove on 12/21/10.
//  Copyright 2010 Panic, Inc. All rights reserved.
//


#import <QuartzCore/QuartzCore.h>

@class PCShadow;

@interface CALayer (Additions)

//- (void)pc_setShadow:(PCShadow*)shadow;
- (void)pc_setContentsScale:(CGFloat)scale;
- (CGFloat)pc_contentsScale;

@end
