/*
 *  NSData-BOM.h
 *
 *  Requires Mac OS X 10.0 or higher
 *
 *
 *	Provides methods for dealing with UTF8 BOM marker.
 *
 *	-------------------------------------------------------------------
 *
 */

#import <Foundation/Foundation.h>

@interface NSData (BOM)

- (BOOL)pc_hasUTF8BOM;
- (NSData*)pc_dataWithUTF8BOM;

@end
