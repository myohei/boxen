#import <Cocoa/Cocoa.h>

/*
 *  PCIconServices.h
 *
 *  Requires Mac OS X 10.4 or higher
 *
 *	A general wrapper for the Icon Manager and Icon Services API with code from IconFamily class.
 *	Allows the user to generate an IconRef from a given set of images.
 *
 *	-------------------------------------------------------------------
 *
 *
 */

@interface PCIconServices : NSObject
{

}

+ (IconRef)createIconRefWith1024:(NSBitmapImageRep*)icon1024 huge:(NSBitmapImageRep*)hugeIcon thumbnail:(NSBitmapImageRep*)thumbnailIcon normal:(NSBitmapImageRep*)normalIcon small:(NSBitmapImageRep*)smallIcon;
+ (IconRef)createIconRefWithHuge:(NSBitmapImageRep*)hugeIcon thumbnail:(NSBitmapImageRep*)thumbnailIcon normal:(NSBitmapImageRep*)normalIcon small:(NSBitmapImageRep*)smallImage;
+ (IconRef)createIconRefWithThumbnail:(NSBitmapImageRep*)thumbnailIcon normal:(NSBitmapImageRep*)normalIcon small:(NSBitmapImageRep*)smallImage;
+ (IconRef)iconRefFromICNSFile:(NSString*)path; // returns a retained icon ref, user should release when done

// private internal methods

+ (Handle)get1BitMaskFromBitmapImageRep:(NSBitmapImageRep*)bitmapImageRep requiredPixelSize:(int)requiredPixelSize;
+ (Handle)get32BitDataFromBitmapImageRep:(NSBitmapImageRep*)bitmapImageRep requiredPixelSize:(int)requiredPixelSize;
+ (Handle)get8BitDataFromBitmapImageRep:(NSBitmapImageRep*)bitmapImageRep requiredPixelSize:(int)requiredPixelSize;
+ (Handle)get8BitMaskFromBitmapImageRep:(NSBitmapImageRep*)bitmapImageRep requiredPixelSize:(int)requiredPixelSize;

+ (BOOL)setIconFamilyElement:(OSType)elementType fromBitmapImageRep:(NSBitmapImageRep*)bitmapImageRep inHandle:(IconFamilyHandle)iconHandle;

@end




