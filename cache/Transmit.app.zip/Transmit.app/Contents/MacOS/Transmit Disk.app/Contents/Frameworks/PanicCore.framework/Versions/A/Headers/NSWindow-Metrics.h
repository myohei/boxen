#import <Cocoa/Cocoa.h>

/*
 *  NSWindow-Metrics.h
 *
 *  Requires Mac OS X 10.2 (?) or higher
 *
 *
 *	Returns various information about window attributes.
 *
 *	-------------------------------------------------------------------
 *
 *
 */
 

@interface NSWindow (PCMetrics)

- (CGFloat)pc_toolbarHeight;
- (CGFloat)pc_titleBarHeight;
- (NSPoint)pc_frameTopLeftPoint;
- (void)pc_centerOnScreen;
- (BOOL)pc_isMaximized;
- (BOOL)pc_isMaximizedVertically;

@end
