#import <Cocoa/Cocoa.h>

@interface NSView (PCLayout)

- (void)pc_centerHorizontallyInSuperview;

@end

@interface NSView (PCViewDebugging)

- (void)pc_logSubviews; // dumps hierarchy using NSLog
- (NSView*)pc_subviewWithDesiredClass:(Class)desired;

@end
