#import <Cocoa/Cocoa.h>


@interface NSResponder (Views)

- (BOOL)pc_isSubviewOf:(NSView*)aView;

@end

@interface NSView (Key)

- (BOOL)pc_showsKey;

@end