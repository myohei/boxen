#import <Foundation/Foundation.h>


@interface PCWorkerThread : NSThread
{
@private
	NSTimeInterval iRunLoopInterval;
	NSConditionLock* iStatus;
}

@property(readonly) NSConditionLock* status;

- (void)setRunLoopInterval:(NSNumber*)interval;

- (void)finish;

@end
