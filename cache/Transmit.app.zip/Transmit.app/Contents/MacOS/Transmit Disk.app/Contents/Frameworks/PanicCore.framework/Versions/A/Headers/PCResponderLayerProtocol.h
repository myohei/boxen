//
//  PCResponderLayerProtocol.h
//  Unison2
//
//  Created by Dave Hayden on 4/23/09.
//  Copyright 2009 Panic, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol PCResponderLayer
@optional
// Return YES to consume the event, NO to continue processing
- (BOOL)layerMouseDown:(NSEvent*)event atPoint:(CGPoint)p;
- (BOOL)layerMouseDragged:(NSEvent*)event atPoint:(CGPoint)p;
- (BOOL)layerMouseUp:(NSEvent*)event atPoint:(CGPoint)p;
@end
