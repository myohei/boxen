/*
 *  PCHUDSearchFieldCell.h
 *
 *  Requires Mac OS X 10.5 or higher 
 *
 *  Categories:
 *
 *	NSBezierPath+MCAdditions.h
 *	NSColor-Additions.h
 *	NSImage-States.h
 *
 *  Resources:
 *
 *  
 *  TO-DO:
 *
 *	Add support for white style pull-down menu
 *
 *
 *	Provides a search field cell that is HUD like in appearance 
 *
 *	-------------------------------------------------------------------
 *
 *
 */


#import <Cocoa/Cocoa.h>


@interface PCHUDSearchFieldCell : NSSearchFieldCell
{

}

@end
