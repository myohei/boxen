// the contents of this file have been relocated to WindowsTypes.h

#import "WindowsTypes.h"
