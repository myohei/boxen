/*
 *  PCDisablingTextField.h
 *
 *  Requires Mac OS X 10.0 or higher
 *
 *	Provides a text field disabled/enabled color of its text
 *
 *	-------------------------------------------------------------------
 *
 * overrides setEnabled:
 */

#import <AppKit/AppKit.h>

@interface PCDisablingTextField : NSTextField 
{

}

@end
