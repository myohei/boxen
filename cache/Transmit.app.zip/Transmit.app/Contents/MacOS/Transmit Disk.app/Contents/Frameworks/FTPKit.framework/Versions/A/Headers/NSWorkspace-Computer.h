#import <Cocoa/Cocoa.h>

@interface NSWorkspace (PCComputer)

- (NSArray*)pc_userNames;
- (NSArray*)pc_groupNames;
- (NSString*)pc_userNameForUID:(uid_t)uid;
- (NSString*)pc_groupNameForGID:(gid_t)gid;

- (LSItemInfoFlags)pc_fileInfoAtPath:(NSString*)aPath; 

@end
