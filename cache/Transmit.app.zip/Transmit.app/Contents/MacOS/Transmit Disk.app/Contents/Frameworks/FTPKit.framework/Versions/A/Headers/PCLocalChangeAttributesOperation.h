#import "PCFSOperation.h"

@interface PCLocalChangeAttributesOperation : PCFSOperation
{
	NSNumber			*iPermissions;
	NSString			*iFileOwner;
	NSString			*iGroup;	
	BOOL				iRecursive;
}


- (id)initWithNodes:(NSArray*)inNodes permissions:(NSNumber*)newPermissions owner:(NSString*)newOwner group:(NSString*)newGroup recursive:(BOOL)inRecursive;

@end
