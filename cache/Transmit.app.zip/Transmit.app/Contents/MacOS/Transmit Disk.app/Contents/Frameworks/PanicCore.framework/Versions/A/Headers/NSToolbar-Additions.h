#import <Cocoa/Cocoa.h>

/*
 *  NSToolbar-Additions.h
 *
 *  Requires Mac OS X 10.0 or higher
 *
 *	Provides methods that NSToolbar should have, but for some reason doesn't.
 *
 *	-------------------------------------------------------------------
 *
 *
 */

@interface NSToolbar (Additions)

- (NSToolbarItem*)itemWithIdentifier:(NSString*)identfier;
- (NSToolbarItem*)visibleItemWithIdentifier:(NSString*)identfier;

@end
