#import "PCRemoteOperation.h"

@class PCRemoteFolderNode;

@interface PCRemoteConnectOperation : PCRemoteOperation
{
	NSString			*iInitialUnicodePath;
	PCRemoteFolderNode	*iInitialNode;
	
	NSString			*iDownloadPath;
}

@property(nonatomic, readonly, copy) NSString* downloadPath; // if initial path points to a file, nil otherwise.

- (id)initWithInitialPath:(NSString*)unicodePath;

@end
