#import <Foundation/Foundation.h>
#import <netinet/in.h>

@interface NSString (PCPOSIXUtilities)

+ (NSString*)pc_confstr:(int)name;
+ (NSString*)pc_strerror:(int)errnum;

- (BOOL)pc_getIPv4Address:(struct in_addr*)outAddress error:(NSError**)outError;
- (BOOL)pc_getIPv6Address:(struct in6_addr*)outAddress error:(NSError**)outError;

@end
