#import <Foundation/Foundation.h>
#import <libkern/OSAtomic.h>


@interface NSSet (PCAdditions)

+ (NSSet*)pc_setByEnumerating:(NSObject<NSFastEnumeration>*)collection;

@end


@interface NSMutableSet (PCAdditions)

- (void)pc_addObject:(id)object;

@end


@interface PCUniquingMutableSet : NSObject
{
@private
	NSMutableSet* iSet;
	OSSpinLock iLock;
}

- (id)uniqueObject:(id<NSObject, NSCopying>)object;

@end
