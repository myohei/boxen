#import "PCFSOperation.h"

@class PCFolderNode;
@class PCNode;

@interface PCLocalNewFileOperation : PCFSOperation
{
	PCFolderNode*	iDestinationFolder;
	NSString*		iNewFilename;
}

@property (nonatomic, copy) NSString *newFilename;

// pass in nil to get default unique name
- (id)initWithDestination:(PCFolderNode*)node name:(NSString*)newName;

- (FTPKitError*)createNewItem; // for subclass

@end
