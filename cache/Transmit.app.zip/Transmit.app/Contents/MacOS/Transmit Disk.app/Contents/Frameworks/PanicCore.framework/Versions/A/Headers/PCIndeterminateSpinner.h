#import <AppKit/AppKit.h>

@class PCTimer;

@interface PCIndeterminateSpinner : NSView
{
	NSUInteger		iAnimationIndex;
	PCTimer*		iAnimationTimer;
	NSMutableArray*	iSpinnerImages;
	BOOL			iUseWhiteSpinner;
	BOOL			iDisplayWhenStopped;
}

- (void)startAnimation:(id)sender;
- (void)stopAnimation:(id)sender;

- (void)setUsesWhiteSpinner:(BOOL)flag;
- (void)setDisplayedWhenStopped:(BOOL)isDisplayed;

@end
