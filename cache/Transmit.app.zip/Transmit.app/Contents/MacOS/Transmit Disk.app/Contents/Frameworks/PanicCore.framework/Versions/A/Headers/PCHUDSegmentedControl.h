#import <Cocoa/Cocoa.h>

@interface PCHUDSegmentedControl : NSSegmentedControl
{
}

@end


@interface PCHUDSegmentedCell : NSSegmentedCell
{
@private
	NSImage		*backgroundImage;
	NSImage		*pressedBackgroundImage;
	NSImage		*selectedBackgroundImage;
	NSImage		*selectedPressedBackgroundImage;
	
	NSSize		cachedImageSize;
	BOOL		shouldDrawCellBackground;
}

- (void)drawFocusRingWithFrame:(NSRect)cellFrame;
- (void)updateBackgroundForSize:(NSSize)aSize;

- (void)drawSegmentBezelGradient:(NSGradient*)gradient intoImage:(NSImage*)controlImage clipPath:(NSBezierPath*)clippingPath;

@end


@interface PCHUDSegmentedLabelCell : NSCell
{
	
}

@end