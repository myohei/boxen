#import <Cocoa/Cocoa.h>


@interface NSMenuItem (PCUtilities)

// Determines the actual visibility of an alternate menu item, as -[NSMenuItem isHidden] does not always take dynamic visibility into account, such as when a modifier key is pressed after the menu has been opened. This method is only accurate when called on an alternate item.
- (BOOL)pc_isHiddenAlternate;

@end
