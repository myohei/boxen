#import <PanicCore/PCTabBarButton.h>

@interface PCTabBarButtonCell : NSButtonCell
{
	BOOL				isRolloverHighlighted;
	
	TabButtonBezelBorderStyle	bezelBorderMask;
}

- (BOOL)isRolloverHighlighted;
- (void)setRolloverHighlighted:(BOOL)flag;

- (NSRect)imageRectForBounds:(NSRect)theRect;
- (NSRect)titleRectForBounds:(NSRect)theRect;

- (void)setBezelBorderMask:(TabButtonBezelBorderStyle)mask;

@end


@interface PCTabBarPopUpButtonCell : NSPopUpButtonCell
{}

@end
