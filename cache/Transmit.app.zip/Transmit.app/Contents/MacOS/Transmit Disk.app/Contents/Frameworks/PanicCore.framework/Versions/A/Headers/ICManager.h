#import <Foundation/Foundation.h>

#define kICManagerName		@"ICManagerName"
#define kICManagerCreator   @"ICManagerCreator"

@interface ICManager : NSObject
{
}

+ (ICManager*)defaultManager;

- (NSString*)downloadFolderPath;
- (NSString*)defaultApplicationForURL:(NSString*)inString;

- (NSString*)stringForKey:(ConstStr255Param)inKey;
- (BOOL)boolForKey:(ConstStr255Param)inKey;

- (BOOL)setProtocolHelperApplication:(NSString*)inPath forScheme:(NSString*)inSheme;
- (BOOL)setProtocolHelperWithCreator:(OSType)inCreator withName:(NSString*)inName forScheme:(NSString*)inScheme;
- (NSString*)pathForProtocolHelperForScheme:(NSString*)inScheme;

- (NSArray*)helperApplicationsForScheme:(NSString*)inScheme;

- (NSString*)mimeTypeForFilename:(NSString*)filename;

@end
