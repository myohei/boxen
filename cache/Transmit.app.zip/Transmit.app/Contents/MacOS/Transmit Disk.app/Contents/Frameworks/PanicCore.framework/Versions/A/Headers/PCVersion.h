//
//  PCVersion.h
//  PanicCore
//
//  Created by Logan Collins on 6/18/12.
//  Copyright (c) 2012 Panic Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


/*!
 * @enum PCVersionReleaseType
 * @abstract Version release types
 * 
 * @constant PCVersionReleaseTypeFinal     Final release
 * @constant PCVersionReleaseTypeAlpha     Alpha release
 * @constant PCVersionReleaseTypeBeta      Beta release
 */
typedef enum : NSUInteger {
    PCVersionReleaseTypeFinal = 0,
    PCVersionReleaseTypeAlpha,
    PCVersionReleaseTypeBeta,
} PCVersionReleaseType;


/*!
 * @class PCVersion
 * @abstract Object representation of a CoreFoundation-style version string
 */
@interface PCVersion : NSObject <NSCopying> {
@private
	NSString *_releaseString;
	NSString *_prereleaseString;
	PCVersionReleaseType _releaseType;
}

/*!
 * @method versionWithString:
 * @abstract Creates a new version from a string
 * 
 * @param string
 * The string containing the version
 * 
 * @result An PCVersion object
 */
+ (PCVersion *)versionWithString:(NSString *)string;

/*!
 * @method systemVersion
 * @abstract Gets the current version of OS X.
 * 
 * @result A PCVersion object
 */
+ (PCVersion *)systemVersion;


/*!
 * @property string
 * @abstract The string representation of the version
 * 
 * @result An NSString object
 */
@property (nonatomic, copy, readonly) NSString *string;

/*!
 * @property releaseType
 * @abstract The version release type
 * 
 * @result An PCVersionReleaseType value
 */
@property (nonatomic, readonly) PCVersionReleaseType releaseType;


/*!
 * @method compare:
 * @abstract Compares the receiver to another version
 * 
 * @param aVersion
 * The second version to compare
 * 
 * @result An NSComparisonResult value
 */
- (NSComparisonResult)compare:(PCVersion *)aVersion;

/*!
 * @method isEqualToVersion:
 * @abstract Determines if the receiver is equal to another version
 * 
 * @param aVersion
 * The second version to compare
 * 
 * @result A BOOL value
 */
- (BOOL)isEqualToVersion:(PCVersion *)aVersion;

/*!
 * @method isLessThanOrEqualToVersion:
 * @abstract Determines if the receiver is less than or equal to another version
 * 
 * @param aVersion
 * The second version to compare
 * 
 * @result A BOOL value
 */
- (BOOL)isLessThanOrEqualToVersion:(PCVersion *)aVersion;

/*!
 * @method isLessThanVersion:
 * @abstract Determines if the receiver is less than another version
 * 
 * @param aVersion
 * The second version to compare
 * 
 * @result A BOOL value
 */
- (BOOL)isLessThanVersion:(PCVersion *)aVersion;

/*!
 * @method isGreaterThanOrEqualToVersion:
 * @abstract Determines if the receiver is greater than or equal to another version
 * 
 * @param aVersion
 * The second version to compare
 * 
 * @result A BOOL value
 */
- (BOOL)isGreaterThanOrEqualToVersion:(PCVersion *)aVersion;

/*!
 * @method isGreaterThanVersion:
 * @abstract Determines if the receiver is greater than another version
 * 
 * @param aVersion
 * The second version to compare
 * 
 * @result A BOOL value
 */
- (BOOL)isGreaterThanVersion:(PCVersion *)aVersion;

@end


/*!
 * @category NSBundle(PCVersion)
 * @abstract Additions to NSBundle for PCVersion
 */
@interface NSBundle (PCVersion)

/*!
 * @method PCVersion
 * @abstract Gets the bundle version as a PCVersion object
 * 
 * @result A PCVersion object, or nil
 */
- (PCVersion *)PCVersion;

@end
