#import <Foundation/Foundation.h>

// Function for localizing things out of the PanicCore bundle's .strings file
extern NSString* PCLocal(NSString* key);

// Function for localizing things out of the host app's .strings file
#if defined(DEBUG)
extern NSString* PCAppLocal(NSString* str);
#else
#define PCAppLocal(str) NSLocalizedString(str, @"")
#endif
