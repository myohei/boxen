#import <Cocoa/Cocoa.h>


@interface NSString (HTML)

- (NSString*)pc_unicodeAsEntities;

@end
