//
//  Protocols.h
//  PanicCore
//
//  Created by Wade Cosgrove on 1/18/10.
//  Copyright 2010 Panic, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@protocol PCViewDraggingDelegateProtocol

- (NSDragOperation)pc_view:(NSView*)dropView validateDrop:(id <NSDraggingInfo>)sender;
- (BOOL)pc_view:(NSView*)dropView performDragOperation:(id <NSDraggingInfo>)sender;

@optional

- (void)pc_view:(NSView*)dropView draggingExited:(id <NSDraggingInfo>)sender;

@end
