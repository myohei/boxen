//
//  PCVersion_Private.h
//  PanicCore
//
//  Created by Logan Collins on 6/18/12.
//  Copyright (c) 2012 Panic Inc. All rights reserved.
//

#import <PanicCore/PCVersion.h>


@interface PCVersion ()

- (id)initWithString:(NSString *)string;

@end
