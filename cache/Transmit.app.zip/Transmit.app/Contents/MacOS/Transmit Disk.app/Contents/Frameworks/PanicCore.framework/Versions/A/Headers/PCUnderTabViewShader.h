#import <Cocoa/Cocoa.h>
#import "PCTabBarButton.h"

@interface PCUnderTabViewShader : NSObject <NSCopying>
{
	BOOL iControlActive;
	
	TabButtonBezelBorderStyle	iBezelBorderMask;
	
	NSCellStateValue iState;
}

@property (getter=isControlActive) BOOL controlActive;
@property TabButtonBezelBorderStyle bezelBorderMask;
@property NSCellStateValue state;


- (void)drawButtonFillInRect:(NSRect)fillRect;
- (void)drawSelectedButtonFillInRect:(NSRect)fillRect;
- (void)drawButtonBezelInRect:(NSRect)bezelRect;

@end
