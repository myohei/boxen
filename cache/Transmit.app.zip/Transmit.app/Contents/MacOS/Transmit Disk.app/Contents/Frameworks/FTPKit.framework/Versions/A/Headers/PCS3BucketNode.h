#import "PCRemoteFolderNode.h"

typedef enum
{
	kS3BucketType = 0,
	kCloudFilesContainerType
}
PCBucketType;

@interface PCS3BucketNode : PCRemoteFolderNode
{
	PCBucketType iBucketType;
}

@property (assign) PCBucketType bucketType;

@end


@interface PCS3BucketRootNode : PCS3BucketNode
{

}

@end
