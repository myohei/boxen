#import <Cocoa/Cocoa.h>

/*
 *  NSObject-AppleScript.h
 *
 *  Requires Mac OS X 10.3 or higher
 *
 *	Provides a wrapper for setting the current script command error
 *
 *	-------------------------------------------------------------------
 *
 *
 */

@interface NSObject (AppleScript)

- (void)setScriptCommandError:(int)errorCode message:(NSString*)errorMessage;

@end
