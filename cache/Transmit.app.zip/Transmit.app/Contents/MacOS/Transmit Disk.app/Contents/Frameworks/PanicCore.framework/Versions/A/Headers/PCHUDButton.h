#import <Cocoa/Cocoa.h>


@interface PCHUDButton : NSButton
{

}

- (void)setCornerRadius:(CGFloat)radius;
- (void)setColor:(NSColor*)aColor;

@end

@interface PCHUDButtonCell : NSButtonCell
{
	CGFloat	radius;
	NSColor	*iColor;
}

@property (retain) NSColor* color;

- (void)initializeCell;
- (void)setCornerRadius:(CGFloat)inRadius;

@end

@interface NSButtonCell (PCHUDButtonCellPrivateToPublic)

- (NSDictionary*)_textAttributes;

@end
