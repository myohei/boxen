/*
 *  PCTruncateSubstitueField.h
 *
 *  Requires Mac OS X 10.4 or higher
 *
 *	Provides a search field subclass that allows the delegate to provide extra functionality.
 *
 *	------------------------------------------------------------------------------
 *
 *
 */

#import <Cocoa/Cocoa.h>


@interface PCSearchField : NSSearchField
{

}

@end


@interface NSObject (PCSearchFieldDelegate)

- (BOOL)searchField:(PCSearchField*)field doCommandBySelector:(SEL)aSelector;

@end
