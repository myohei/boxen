//
//  PCGradientAppearance.h
//  PanicCore
//
//  Created by Logan Collins on 3/23/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PanicCore/PCAppearance.h>


/*!
 * @class PCGradientAppearanceFactory
 * @abstract Factory for the Panic gradient UI element appearance
 */
@interface PCGradientAppearanceFactory : NSObject <PCAppearanceFactory>

@end
