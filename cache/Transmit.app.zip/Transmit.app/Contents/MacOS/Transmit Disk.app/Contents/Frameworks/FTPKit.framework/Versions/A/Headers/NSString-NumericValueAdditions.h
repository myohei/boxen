#import <Foundation/Foundation.h>

@interface NSString (NumericValueAdditions)

+ (NSString*)ftp_stringWithFloat:(float)aFloat maxFractionalDigits:(short)maxFracDigits;

- (unsigned long long)ftp_unsignedLongLongValue;

@end
