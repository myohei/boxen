#import <Cocoa/Cocoa.h>


@interface NSShadow (Additions)

+ (NSShadow*)pc_shadow;
+ (NSShadow*)pc_shadowWithColor:(NSColor*)shadowColor;
+ (NSShadow*)pc_shadowWithColor:(NSColor*)shadowColor offset:(NSSize)offset;
+ (NSShadow*)pc_shadowWithColor:(NSColor*)shadowColor offset:(NSSize)offset radius:(CGFloat)radius;

// faster than saving/restoring the entire graphics state
+ (void)pc_clearShadowOnCurrentGraphicsContext;
+ (void)pc_clearShadowOnGraphicsContext:(NSGraphicsContext*)context;
- (void)pc_clearShadowOnCurrentGraphicsContext;

@end
