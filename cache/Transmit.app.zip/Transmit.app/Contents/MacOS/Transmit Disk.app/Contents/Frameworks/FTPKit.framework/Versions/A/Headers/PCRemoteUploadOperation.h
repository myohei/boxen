#import "FTPKitConstants.h"
#import "PCRemoteTransferOperation.h"

@class PCFileNode;
@class PCRemoteFolderNode;

@interface PCRemoteUploadOperation : PCRemoteTransferOperation
{
@private
	NSString*		iDestinationPath;
	NSDate*			iLastUIUpdate;
	NSArray*		iNewNames;
	BOOL			iAtomicUpload;
}

@property (readwrite, getter=isAtomicUpload) BOOL atomicUpload;

- (id)initWithNodes:(NSArray*)someNodes remotePath:(NSString*)destinationPath conflictMode:(FTPKitConflictMode)conflictMode;
- (id)initWithNodes:(NSArray*)someNodes newNames:(NSArray*)newNames remotePath:(NSString*)destinationPath conflictMode:(FTPKitConflictMode)conflictMode;

@end
