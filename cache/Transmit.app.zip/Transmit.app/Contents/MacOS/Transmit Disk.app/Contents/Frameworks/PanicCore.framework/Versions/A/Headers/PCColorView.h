#import "PCAppearanceView.h"

/*
 *  PCColorView.h
 *
 *  Requires Mac OS X 10.0 or higher
 *
 *	Draws the specified color as the view's background.
 *
 *	-------------------------------------------------------------------
 *
 *
 */


@interface PCColorView : PCAppearanceView
{
	NSColor* iActiveColor;
	NSColor* iInactiveColor;
	BOOL iAcceptsMouseDown;
}

@property (nonatomic, retain) NSColor *color;
@property (nonatomic, retain) NSColor *inactiveColor;
@property (nonatomic) BOOL acceptsMouseDown;

@end
