#import <Cocoa/Cocoa.h>


@interface PCPlaceholderTextView : NSTextView
{
	NSAttributedString *iPlaceholderString;
}

@property (nonatomic, copy) NSAttributedString *attributedPlaceholderString;
@property (nonatomic, copy) NSString *placeholderString;

@end