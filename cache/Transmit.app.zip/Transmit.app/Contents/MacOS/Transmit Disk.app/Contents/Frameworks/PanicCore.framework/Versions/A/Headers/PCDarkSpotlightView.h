#import <Cocoa/Cocoa.h>


@interface PCDarkSpotlightView : NSView 
{
	NSImage *iBackgroundImage;
}

// private
- (void)updateBackgroundImageWithSize:(NSSize)newSize;

@end
