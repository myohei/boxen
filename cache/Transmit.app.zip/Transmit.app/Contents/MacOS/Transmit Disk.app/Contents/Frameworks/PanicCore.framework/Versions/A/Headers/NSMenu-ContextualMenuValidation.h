#import <AppKit/AppKit.h>


@interface NSMenu (PCContextualMenuValidation)

- (NSMenu*)pc_validatedContextualMenu;
- (void)pc_removeAllItems;

@end
