#import <Cocoa/Cocoa.h>

@interface PCCrypt : NSObject
{
}

+ (NSData*)cipherData:(NSData*)data cipher:(CSSM_ALGORITHMS)encryptionAlg key:(NSString*)key encrypt:(BOOL)flag;
+ (NSData*)encryptData:(NSData*)data key:(NSString*)key;
+ (NSData*)decryptData:(NSData*)data key:(NSString*)key;
+ (NSString*)stupidCrypt:(NSString*)inString;

@end
