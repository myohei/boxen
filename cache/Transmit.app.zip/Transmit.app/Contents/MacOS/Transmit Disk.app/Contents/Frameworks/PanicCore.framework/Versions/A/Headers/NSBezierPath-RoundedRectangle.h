#import <Cocoa/Cocoa.h>


@interface NSBezierPath (RoundedRectangle)

+ (NSBezierPath*)pc_normalRoundedRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth __attribute__((deprecated));
+ (NSBezierPath*)pc_roundedRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

// a rectangle with its top corners rounded, bottom are square
+ (NSBezierPath*)pc_roundedTopRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

// a rectangle with its bottom corners rounded, top are square
+ (NSBezierPath*)pc_roundedBottomRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

@end

@interface NSBezierPath (RoundedRectangleDeprecated)

+ (NSBezierPath*)roundedRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth __attribute__((deprecated));

// a rectangle with its top corners rounded, bottom are square
+ (NSBezierPath*)roundedTopRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth __attribute__((deprecated));

// a rectangle with its bottom corners rounded, top are square
+ (NSBezierPath*)roundedBottomRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth __attribute__((deprecated)); 

@end
