#import <Cocoa/Cocoa.h>


@interface NSView (PCWindowResizing)

- (void)pc_changeWindowHeightBy:(CGFloat)amount;
- (void)pc_changeWindowHeightBy:(CGFloat)amount resizeViewHeight:(BOOL)heightResizeFlag; // same as above but allows resizing of self vertically

- (void)pc_restoreAutoresizeMasks:(NSArray*)masks toViews:(NSArray*)views;
- (NSArray*)pc_setupAutoresizeMasksForResize:(NSArray**)resizeMasks resizeViewHeight:(BOOL)heightResizeFlag;

@end
