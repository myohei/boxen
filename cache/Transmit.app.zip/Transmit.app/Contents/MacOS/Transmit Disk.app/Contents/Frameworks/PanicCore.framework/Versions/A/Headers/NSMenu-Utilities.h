#import <Cocoa/Cocoa.h>
#import <Carbon/Carbon.h>


@interface NSMenu (PCUtilities)

#if !defined(MACAPPSTORE)
- (MenuRef)pc_carbonMenu;
#endif

- (NSMenuItem*)pc_itemWithRepresentedObject:(id)anObject;
- (void)pc_setActionForMenuItems:(SEL)action target:(id)target;
- (NSMenuItem*)pc_selectedItem;

- (NSMenuItem*)pc_checkedItem;
- (void)pc_checkItemWithTag:(NSInteger)tag byExtendingSelection:(BOOL)flag;
- (void)pc_uncheckAll;

@end


@interface NSMenu (PCItemEnumerator)

- (NSEnumerator*)pc_itemEnumerator;
- (NSEnumerator*)pc_recursiveItemEnumerator;

@end
