//
//  PCAppearance.h
//  PanicCore
//
//  Created by Logan Collins on 3/23/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


/*!
 * @enum PCAppearanceBorder
 * @abstract Bitmask values for borders
 * 
 * @constant PCAppearanceBorderNone      No borders
 * @constant PCAppearanceBorderTop       Top border
 * @constant PCAppearanceBorderBottom    Bottom border
 * @constant PCAppearanceBorderLeft      Left border
 * @constant PCAppearanceBorderRight     Right border
 * @constant PCAppearanceBorderAll       All borders
 */
enum {
    PCAppearanceBorderNone = 0,
    
    PCAppearanceBorderTop = (1 << 0),
    PCAppearanceBorderBottom = (1 << 1),
    PCAppearanceBorderLeft = (1 << 2),
    PCAppearanceBorderRight = (1 << 3),
    
    PCAppearanceBorderAll = (PCAppearanceBorderTop|PCAppearanceBorderBottom|PCAppearanceBorderLeft|PCAppearanceBorderRight),
};
typedef NSUInteger PCAppearanceBorder;


/*!
 * @enum PCAppearanceState
 * @abstract Bitmask values for control state
 * 
 * @constant PCAppearanceStateNormal        The UI element is in its default state, enabled but not selected in any way
 * @constant PCAppearanceStateHighlighted   The UI element is highlighted (through a click, tap or tracking)
 * @constant PCAppearanceStateDisabled      The UI element is disabled
 * @constant PCAppearanceStateSelected      The UI element is selected (as in a selected segmented control segment)
 * @constant PCAppearanceStateHovered       The UI element is hovered (through a mouse hover or drag hover)
 * @constant PCAppearanceStateFocused		The UI element is focused (or within a focused container)
 */
enum {
    PCAppearanceStateNormal = 0,
    
    PCAppearanceStateHighlighted = (1 << 0),
    PCAppearanceStateDisabled = (1 << 1),
    PCAppearanceStateSelected = (1 << 2),
    PCAppearanceStateHovered = (1 << 3),
	PCAppearanceStateFocused = (1 << 4),
};
typedef NSUInteger PCAppearanceState;


/*!
 * @protocol PCAppearanceFactory
 * @abstract Implemented by objects able to generate appearance resources
 */
@protocol PCAppearanceFactory <NSObject>

/*!
 * @method backgroundImageWithSize:border:state:
 * @abstract Creates a background image
 * 
 * @param size
 * The size of the image
 * 
 * @param borders
 * The borders for the image
 * 
 * @param state
 * The state of the image
 * 
 * @result An NSImage object
 */
+ (NSImage *)backgroundImageWithSize:(NSSize)size border:(PCAppearanceBorder)border state:(PCAppearanceState)state;

@end
