#import <Cocoa/Cocoa.h>


@interface NSTextField (Appearance)

- (void)setEnabledAppearanceSavvy:(BOOL)flag;

@end
