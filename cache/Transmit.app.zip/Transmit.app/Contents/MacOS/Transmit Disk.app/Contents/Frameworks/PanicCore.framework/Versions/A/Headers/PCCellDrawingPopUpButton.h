// One PopUpButton to rule them all!
// Supports any type of button cell, say goodbye to writing one-off popup buttons. Yay!
//
// FEATURES TO ADD: the ability to draw arrows

#import <PanicCore/PCActionPopUpButton.h>

@interface PCCellDrawingPopUpButton : PCActionPopUpButton 
{
	NSTrackingArea *iRolloverTrackingArea;
}

@property (nonatomic, retain) NSButtonCell* drawingCell;

@end


@interface PCCellDrawingPopUpButtonCell : PCActionPopUpButtonCell 
{
	NSButtonCell *iDrawingCell;
}

@property (nonatomic, retain) NSButtonCell *drawingCell;
@property (nonatomic, getter=isRolloverHighlighted) BOOL rolloverHighlighted;
@property (nonatomic, readonly) BOOL supportsRollover;

@end
