//
//  PCIconTextField.h
//  Studio
//
//  Created by Wade Cosgrove on 3/29/06.
//  Copyright 2006 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PCIconTextField : NSTextField
{
}

- (void)setAccessoryAction:(SEL)selector;
- (void)setAccessoryImage:(NSImage*)anImage;
- (void)setAccessoryTarget:(id)target;

- (void)setImage:(NSImage*)anImage;

- (BOOL)trackAccessoryCellWithEvent:(NSEvent*)theEvent;

@end
