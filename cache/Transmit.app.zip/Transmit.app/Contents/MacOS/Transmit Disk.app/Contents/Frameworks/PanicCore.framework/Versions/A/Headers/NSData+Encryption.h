//
//  NSData+Encryption.h
//  PanicCore
//
//  Created by Logan Collins on 8/24/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


/*!
 * @category NSData(Encryption)
 * @abstract Additions to NSData for encrypted operations
 */
@interface NSData (Encryption)

/*!
 * @method pc_randomDataOfLength:
 * @abstract Generates random data of a specified length
 *
 * @param length
 * The length of data to generate.
 *
 * @discussion
 * This method reads a series of bytes from /dev/random.
 *
 * @result An NSData object
 */
+ (NSData *)pc_randomDataOfLength:(NSUInteger)length;


/*!
 * @method pc_dataByEncryptingWithPassphrase:error:
 * @abstract Encrypts the receiver using a passphrase
 *
 * @param passphrase
 * The passphrase to use for encryption
 *
 * @param outError
 * On failure out, an error object describing the issue
 *
 * @result An NSData object, or nil
 */
- (NSData *)pc_dataByEncryptingWithPassphrase:(NSString *)passphrase error:(NSError **)outError;

/*!
 * @method pc_dataByDecryptingWithPassphrase:error:
 * @abstract Decrypts the receiver using a passphrase
 *
 * @param passphrase
 * The passphrase to use for decryption
 *
 * @param outError
 * On failure out, an error object describing the issue
 *
 * @result An NSData object, or nil
 */
- (NSData *)pc_dataByDecryptingWithPassphrase:(NSString *)passphrase error:(NSError **)outError;

@end
