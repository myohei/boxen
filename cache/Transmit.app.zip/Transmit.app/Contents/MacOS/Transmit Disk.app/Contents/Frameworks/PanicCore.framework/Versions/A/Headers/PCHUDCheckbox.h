#import <Cocoa/Cocoa.h>

@interface PCHUDCheckbox : NSButton
{
}

// private
- (void)configure;

@end


@interface PCHUDCheckboxCell: NSButtonCell
{
}


@end