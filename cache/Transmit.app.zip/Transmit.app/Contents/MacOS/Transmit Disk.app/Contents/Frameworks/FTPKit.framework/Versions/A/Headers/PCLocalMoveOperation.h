#import "PCFSOperation.h"

@class PCFolderNode;

@interface PCLocalMoveOperation : PCFSOperation
{
	PCFolderNode* iDestinationNode;
	FTPKitConflictMode iConflictMode;
}

- (id)initWithNodes:(NSArray*)nodes destinationPath:(NSString*)destinationPath conflictMode:(FTPKitConflictMode)conflictMode;

- (BOOL)shouldProceedAfterNSFileManagerError:(NSError *)error sourcePath:(NSString *)srcPath;

@end
