#import <Cocoa/Cocoa.h>


@interface NSTextField (EmptyStringAsNil)

- (NSString*)stringValueEmptyAsNil;
- (void)setStringValueNilAsEmpty:(NSString*)aString;

@end
