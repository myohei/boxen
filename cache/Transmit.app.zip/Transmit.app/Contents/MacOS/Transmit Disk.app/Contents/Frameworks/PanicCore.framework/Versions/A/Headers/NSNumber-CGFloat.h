#import <Foundation/Foundation.h>


// why does CFNumber support CGFloat but not NSNumber? the world may never know.

@interface NSNumber (PCCGFloat)

+ (NSNumber*)pc_numberWithCGFloat:(CGFloat)value;

- (CGFloat)pc_CGFloatValue;

@end
