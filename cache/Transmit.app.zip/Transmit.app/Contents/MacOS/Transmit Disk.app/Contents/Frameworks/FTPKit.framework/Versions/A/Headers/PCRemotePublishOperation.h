#import <Cocoa/Cocoa.h>
#import "FTPKitConstants.h"
#import "PCRemoteTransferOperation.h"

@class AbstractConnection;
@class PCRemoteFileNode;

@interface PCRemotePublishOperation : PCRemoteTransferOperation
{
	NSString* iLocalPath;
	NSString* iRemotePath;
}

- (id)initWithNodes:(NSArray*)someNodes localRootPath:(NSString*)localPath remoteRootPath:(NSString*)remotePath conflictMode:(FTPKitConflictMode)aConflictMode;

@end
