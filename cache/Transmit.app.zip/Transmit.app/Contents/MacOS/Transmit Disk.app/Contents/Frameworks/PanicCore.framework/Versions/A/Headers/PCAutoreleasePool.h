#import <Cocoa/Cocoa.h>


@interface PCAutoreleasePool : NSObject 
{
	NSUInteger iFlushInterval;
	NSUInteger iFlushCounter;
	NSAutoreleasePool *iAutoreleasePool;
}

@property (assign) NSUInteger flushInterval;

- (void)increment;
- (void)drain;

@end
