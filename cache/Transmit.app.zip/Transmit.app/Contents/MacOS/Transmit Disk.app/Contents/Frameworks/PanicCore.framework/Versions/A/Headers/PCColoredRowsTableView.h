#import "PCBaseTableView.h"

@interface PCColoredRowsTableView : PCBaseTableView
{
	NSColor *rowColor1;
	NSColor *rowColor2;
}

- (void)setAlternatingRowColor1:(NSColor*)color1 color2:(NSColor*)color2;

@end

@interface NSTableView (AlternateRowDrawing)
- (void)_drawAlternatingRowBackgroundColors:(NSArray*)colors inRect:(NSRect)aRect;
@end
