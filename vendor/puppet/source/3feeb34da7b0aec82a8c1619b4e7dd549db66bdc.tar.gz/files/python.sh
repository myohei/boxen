export PATH=$BOXEN_HOME/homebrew/share/python:$PATH
